const fs = require("fs");
const fsPromise = require("fs").promises;
const path = require("path");
const productDataPath = path.join(__dirname, "..", "data", "products.json");

class Product {
  async getAll() {
    return fsPromise
      .readFile(path.join(__dirname, "..", "data", "products.json"), {
        encoding: "utf-8",
      })
      .then((data) => {
        // console.log(data);

        let jsonData = JSON.parse(data);
        return { success: true, data: jsonData };
      })
      .catch((error) => {
        // console.log(error);
        return { success: false };
      });
  }

  // Later
  // // async getByQuery(queryParams) {
  // //   for (const key in queryParams) {
  // //     // console.log(`${key} is ${queryParams[key]}`);

  // //   }
  // // }


  async addProduct(product) {
    const { title, description, price, stock } = product;
    const errors = {};
    
    if(!title || title === ""){
      errors.title="Add a title";
    }
    if(!description){
      errors.description="Add a description";
    }
    if (description) {
      if (description.length < 30) {
        errors.description="Description should be atleast 30 characters long";
        // dummy description: 
        // For 2023, Samsung has refined its flagship smartphone. 
        // For 2023, Samsung has refined its flagship smartphone.
      } 
    }
    if(!price){
      errors.price="Price is not provided";
    }
    if (price) {
      if (price <= 50) {
        errors.price="Price should be more than 50";
      } 
    }
    if(!stock || stock <=0){
      errors.stock="Add some stock";
    }
    
    if (Object.keys(errors).length > 0) {
        // console.log(errors);
      return { success: false, errors: errors};
    }
    return fsPromise
        .readFile(productDataPath, { encoding: "utf-8" })
        .then((data) => {
            const jsonProductData = JSON.parse(data);
            product = { "id": jsonProductData[jsonProductData.length-1].id+1, ...product};
            jsonProductData.push(product);
            data = JSON.stringify(jsonProductData);
            return fsPromise
                .writeFile(productDataPath, data)
                .then(() => {
                    return { success: true, data: JSON.parse(data) };
                })    
                .catch((error) => {
                    return { success: false };
                });
        })
        .catch((error) => {
            return { success: false };
        });
  }

  async getById(id) {
    console.log(id);

    return fsPromise
      .readFile(productDataPath, { encoding: "utf-8" })
      .then((data) => {
        
        let jsonData = JSON.parse(data);
        const foundData = jsonData.find(element => element.id === id);
        if (foundData) {
          // If data is found with the corresponding ID, then only that data will be returned
          return { success: true, data: foundData };
        }
        return { success: false, error: 404 };
      })
      .catch((error) => {
        // console.log(error);
        return { success: false };
      });
  }

  async updateById(id, product) {
    console.log(id);

    return fsPromise
      .readFile(productDataPath, { encoding: "utf-8" })
      .then((data) => {
        
        let jsonData = JSON.parse(data);
        const updatedData = jsonData.map((element) => {
          if (element.id === id) {
            flag = true;
            if (product.id) {
              return { ...element, ...product, id: element.id };
            }
            return { ...element, ...product };
          }
          // return element;
        });
        if (flag) {
          return fsPromise
            .writeFile(productDataPath, JSON.stringify(updatedData))
            .then(() => {
                return { success: true, data: JSON.parse(updatedData) };
            })    
            .catch((error) => {
                return { success: false };
            });
          return { success: true, data: foundData };
        }
        return { success: false, error: 404 };
      })
      .catch((error) => {
        // console.log(error);
        return { success: false };
      });
  }

}

module.exports = new Product();
